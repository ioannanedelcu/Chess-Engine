#pragma once
#ifndef CHESS_PROJECT_AI_H
#define CHESS_PROJECT_AI_H

#include "board.h"

using namespace std;

//extern int piece_number;
int alphabeta(int alpha, int beta, int depth, Board &board);
MOVE searchBestMove(Board &board);

#endif