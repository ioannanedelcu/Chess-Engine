#include <chrono>
#include "ai.h"

/*
bool castling_done;
bool timeout = false;
auto start = std::chrono::high_resolution_clock::now();
double timeout_time = 7;
MOVE bestMove;
MOVE globalBestMove;
int currentDepth;
*/

int alphabeta(int alpha, int beta, int depth, Board &board) {

    int best_score = -BESTSCORE;

    if (depth <= 0) {
        best_score = board.eval();
        if (best_score > alpha) {
            alpha = best_score;
        }
        if (best_score >= beta || depth < -1)
            return best_score;
    }


    vector<MOVE> moves = board.findLegalMoves();

    for (int i = 0; i < moves.size(); i++) {

        // Opponent's king can be captured. That means he is check-mated.
        if (moves[i].captured == BK || moves[i].captured == WK) {
            return 9000 + depth;
        }

        if (depth <= 0 && moves[i].captured == 0)
            continue;

        Board copy(board);
        copy.makeMove(moves[i]);
        int score = - alphabeta(-beta, -alpha, depth - 1, copy);

        if (score > best_score) {
            best_score = score;
        }
        if (best_score > alpha) {
            alpha = best_score;
        }

        if (alpha >= beta) {
            break;
            // cut-off
        }
    }
    return best_score;
}

MOVE searchBestMove(Board &board) {


    vector<MOVE> legalMoves = board.findLegalMoves();
    vector<MOVE> bestMoves;
    int best_score = -BESTSCORE;

    int d = DEPTH;
    if (board.getPiecenumber() <= 12)
        d++;

    for (int i = 0; i < legalMoves.size(); i++) {
            Board copy(board);
            copy.makeMove(legalMoves[i]);
            copy.swapSides();
            if (copy.isMyKingInCheck())
                continue;
            copy.swapSides();

            int score = -alphabeta(-BESTSCORE, BESTSCORE, d, copy);

            if (score > best_score) {
                best_score = score;
                bestMoves.clear();
                bestMoves.push_back(legalMoves[i]);
            } else if (score == best_score) {
                bestMoves.push_back(legalMoves[i]);
            }
    }
    //srand((int)time(0));
    //int randomIndex = rand() % bestMoves.size();
    return bestMoves[bestMoves.size() - 1];
}

//LIMITING MOVES IN THE BEGINNING-PHASE OF THE GAME
/*
MOVE searchBestMove(Board &board) {

    //ofstream fcout("out.txt");
    vector<MOVE> legalMoves;
    vector<MOVE> bestMoves;
    int best_score = -BESTSCORE;

    int d = DEPTH;
    if (board.getPiecenumber() <= 14) {
        d++;
        if (board.getPiecenumber() <= 6) {
            d++;
        }
    }
    if (!castling_done) {
        legalMoves = board.findLegalBeginMoves();
    } else {
        legalMoves = board.findLegalMoves();
    }


    for (int i = 0; i < legalMoves.size(); i++) {
        Board copy(board);
        copy.makeMove(legalMoves[i]);
        copy.swapSides();
        if (copy.isMyKingInCheck())
            continue;

        copy.swapSides();

        int score = -minimax(-BESTSCORE, BESTSCORE, d, copy);

        if (score > best_score) {
            best_score = score;
            bestMoves.clear();
            bestMoves.push_back(legalMoves[i]);
        } else if (score == best_score) {
            bestMoves.push_back(legalMoves[i]);
        }
    }

    MOVE move = bestMoves[bestMoves.size() - 1];
    /*if (!beginbits.all()) {
    	if (move.piece == WN | move.piece == BK) {
    		if (!beginbits[0]) {
    			beginbits.set(0);
    		} else {
    			beginbits.set(1);
    		}
    	}
    	if (move.piece == WB | move.piece == BB) {
    			beginbits.set(2);
    	}
    }
    if (move.castling) {
        castling_done = true;
    }
    return move;
}*/



// QUISCENCE SEARCH - FIRST TRY
/*
int quiesce(int alpha, int beta, Board &board) {
    int stand_pat = board.eval();
    if (stand_pat >= beta) {
        return beta;
    }
    if (alpha < stand_pat) {
        alpha = stand_pat;
    }

    vector<MOVE> moves = board.findLegalMoves();
    for (int i = 0; i < moves.size(); i++) {
        if (moves[i].captured != 0) {
            Board copy(board);
            copy.makeMove(moves[i]);
            int score = -quiesce(-beta, -alpha, copy);

            if (score >= beta) {
                return beta;
            }
            if (score > alpha) {
                alpha = score;
            }
        }
    }
    return alpha;
}*/


//ITERATIVE DEEPENING - FAIL
/*
MOVE searchBestMove(Board &board) {

    timeout = false;
    start = std::chrono::high_resolution_clock::now();

    for (int d = 0;; d++) {
        if (d > 0) {
            globalBestMove = bestMove;
        }
        currentDepth = DEPTH + d;
        minimax(-BESTSCORE, BESTSCORE, currentDepth, board);

        if (timeout)
            return globalBestMove;
    }
}

int minimax(int alpha, int beta, int depth, Board &board) {

    auto end = std::chrono::high_resolution_clock::now();
    if (end - start > (std::chrono::duration<double>)timeout_time) {
        timeout = true;
        return alpha;
    }

    if (depth == 0) {
        return board.eval();
    }

    vector<MOVE> moves = board.findLegalMoves();
    //printf("moves size: %d, side: %d", moves.size(), board.getStm());


    for (int i = 0; i < moves.size(); i++) {

        // Opponent's king can be captured. That means he is check-mated.
        if (moves[i].captured == BK || moves[i].captured == WK) {
            return 9000 + depth;
        }

        Board copy(board);
        copy.makeMove(moves[i]);
        int score = - minimax(-beta, -alpha, depth - 1, copy);

        if (score > alpha) {
            alpha = score;

            if (depth == currentDepth)
                bestMove = moves[i];
        }

        if (alpha >= beta) {
            break;
            // cut-off
        }
    }
    return alpha;
}*/
